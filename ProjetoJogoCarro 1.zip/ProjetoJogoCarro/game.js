let canvas = document.getElementById("myCanvas")
let ctx = canvas.getContext("2d")

var myScore;

var teclas = {};

let pista = {
    x: 0,
    y: 0,
    largura:350,
    altura:600,
}

let pista2 = {
    x: 350,
    y: 0,
    largura:350,
    altura:600,
}

let pista3 = {
    x: 700,
    y: 0,
    largura:300,
    altura:600,
}

let carro_branco = {
    x: 500,
    y: 600 - 140,
    largura: 60,
    altura: 130,
    speed: 5,
    score: 0,
}

let carro_roxo = {
    x: 650,
    y: 0,
    largura: 60,
    altura: 130,
    speed: 6,
    aux:true,
}

let carro_vermelho = {
    x: 300,
    y: 0,
    largura: 60,
    altura: 130,
    speed: 4,
    aux:true,
}

let carro_amarelo = {
    x: 50,
    y: 0,
    largura: 60,
    altura: 130,
    speed:5,
    aux:true,
}

let carro_azul = {
    x: 800,
    y: 0,
    largura: 60,
    altura: 130,
    speed: 3,
    aux:true,
}

let PONTOS = 0;

function desenha(){
    let imagem_pista = new Image();
    imagem_pista.src = "pista.png";
    ctx.drawImage(imagem_pista,pista.x,pista.y,pista.largura,pista.altura)

    let imagem_pista2 = new Image();
    imagem_pista2.src = "pista.png";
    ctx.drawImage(imagem_pista2,pista2.x,pista2.y,pista2.largura,pista2.altura)

    let imagem_pista3 = new Image();
    imagem_pista3.src = "pista.png";
    ctx.drawImage(imagem_pista3,pista3.x,pista3.y,pista3.largura,pista3.altura)


    let imagem_carro_branco = new Image();
    imagem_carro_branco.src = "carrobranco.png";
    ctx.drawImage(imagem_carro_branco,carro_branco.x,carro_branco.y,carro_branco.largura,carro_branco.altura)

    let imagem_carro_roxo = new Image();
    imagem_carro_roxo.src = "carroroxo.png";
    ctx.drawImage(imagem_carro_roxo,carro_roxo.x,carro_roxo.y,carro_roxo.largura,carro_roxo.altura)

    let imagem_carro_vermelho = new Image();
    imagem_carro_vermelho.src = "carrovermelho.png";
    ctx.drawImage(imagem_carro_vermelho,carro_vermelho.x,carro_vermelho.y,carro_vermelho.largura,carro_vermelho.altura)

    let imagem_carro_amarelo = new Image();
    imagem_carro_amarelo.src = "carroamarelo.png";
    ctx.drawImage(imagem_carro_amarelo,carro_amarelo.x,carro_amarelo.y,carro_amarelo.largura,carro_amarelo.altura)

    let imagem_carro_azul = new Image();
    imagem_carro_azul.src = "carroazul.png";
    ctx.drawImage(imagem_carro_azul,carro_azul.x,carro_azul.y,carro_azul.largura,carro_azul.altura)
}

document.addEventListener("keydown", function(e) {
    teclas[e.keyCode] = true;
    //alert(e.keyCode);
}, false);


document.addEventListener("keyup", function(e) {
    delete teclas[e.keyCode];
}, false);

function move_carro_branco(){
    if (39 in teclas && carro_branco.x < canvas.width - carro_branco.largura)
        carro_branco.x += carro_branco.speed;
    else if (37 in teclas && carro_branco.x > 0){
        carro_branco.x -= carro_branco.speed;
    }
}

function verificar(obj){
    if(obj.x>carro_branco.x && obj.x<carro_branco.x+carro_branco.largura ){
        if(obj.y+obj.altura>carro_branco.y) {
            if(obj.y<carro_branco.y+carro_branco.altura){
                alert('Game Over! \n Reinicie a Página Para Jogar Novamente! \n Pontos: '+PONTOS)
            }
        }
    }

}

function move_carro_amarelo(){
    carro_amarelo.y = carro_amarelo.y + carro_amarelo.speed;
    carro_amarelo.speed = carro_amarelo.speed + 0.0001;
    if (carro_amarelo.y > canvas.width){
        PONTOS++;
        console.log(PONTOS);
        carro_amarelo.y = -300;
        carro_amarelo.x = Math.floor(Math.random()*
            (canvas.width - carro_amarelo.x))
    }
    verificar(carro_amarelo);
}

function move_carro_vermelho(){
    carro_vermelho.y = carro_vermelho.y + carro_vermelho.speed;
    carro_vermelho.speed = carro_vermelho.speed + 0.0001;
    if (carro_vermelho.y > canvas.width){
        PONTOS++;
        console.log(PONTOS);
        carro_vermelho.y = -50;
        carro_vermelho.x = Math.floor(Math.random()*
            (canvas.width - carro_amarelo.x))
    }
    verificar(carro_vermelho);
}

function move_carro_roxo(){
    carro_roxo.y = carro_roxo.y + carro_roxo.speed;
    carro_roxo.speed = carro_roxo.speed + 0.0001;
    if (carro_roxo.y > canvas.width){
        PONTOS++;
        console.log(PONTOS);
        carro_roxo.y = -200;
        carro_roxo.x = Math.floor(Math.random()*
            (canvas.width - carro_roxo.x))
    }
    verificar(carro_roxo)
}

function move_carro_azul(){
    carro_azul.y = carro_azul.y + carro_azul.speed;
    carro_azul.speed = carro_azul.speed + 0.0001;
    if (carro_azul.y > canvas.width){
        PONTOS++;
        console.log(PONTOS);
        carro_azul.y  = -100;
        carro_azul.x = Math.floor(Math.random()*
            (canvas.width - carro_azul.x))
    }
    verificar(carro_azul)
}






function atualizar(){
    desenha()
    move_carro_amarelo()
    move_carro_vermelho()
    move_carro_roxo()
    move_carro_azul()
    move_carro_branco()
    requestAnimationFrame(main)
}

function main(){
    atualizar()
}

